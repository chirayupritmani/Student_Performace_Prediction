import joblib
import pandas as pd

MODEL_PATH = "outputs/final_model.pkl"

artifact = joblib.load(MODEL_PATH)

preprocessor = artifact["preprocessor"]
encoder = artifact["target_encoder"]
selected_indices = artifact["selected_indices"]
model = artifact["model"]

def predict_student(student_dict):
    df = pd.DataFrame([student_dict])

    X = preprocessor.transform(df)
    X = X[:, selected_indices]

    pred = model.predict(X)[0]
    label = encoder.inverse_transform([pred])[0]

    result = {
        "predicted_class": str(label)
    }

    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(X)[0]
        result["confidence"] = float(max(probs))

    return result


# Example:
# Change the keys to match your dataset columns.
#
# student = {
#     "Attendance": 85,
#     "StudyHours": 5,
#     "PreviousScore": 72
# }
#
# print(predict_student(student))
